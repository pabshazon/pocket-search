from transformers import AutoTokenizer, AutoModelForCausalLM
import torch

# Proper device handling @todo add apple silicon
if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")

amateur_path = 'Qwen/Qwen2.5-Coder-0.5B-Instruct'
expert_path = 'Qwen/Qwen2.5-Coder-1.5B-Instruct'

tokenizer = AutoTokenizer.from_pretrained(amateur_path)

# Load models with correct device mapping
model_amateur = AutoModelForCausalLM.from_pretrained(
    amateur_path,
    torch_dtype=torch.float16 if device.type != "cpu" else torch.float32,
    device_map="auto" if device.type == "cuda" else None
)
model_expert = AutoModelForCausalLM.from_pretrained(
    expert_path,
    torch_dtype=torch.float16 if device.type != "cpu" else torch.float32,
    device_map="auto" if device.type == "cuda" else None
)

user_message = """Give a very very brief docstring for the following function:\n```\nfunction updateEloScores(
	scores,
	results,
	kFactor = 4,
) {
	for (const result of results) {
		const { first, second, outcome } = result;
		const firstScore = scores[first] ?? 1000;
		const secondScore = scores[second] ?? 1000;

		const expectedScoreFirst = 1 / (1 + Math.pow(10, (secondScore - firstScore) / 400));
		const expectedScoreSecond = 1 / (1 + Math.pow(10, (firstScore - secondScore) / 400));
		let sa = 0.5;
		if (outcome === 1) {
			sa = 1;
		} else if (outcome === -1) {
			sa = 0;
		}
		scores[first] = firstScore + kFactor * (sa - expectedScoreFirst);
		scores[second] = secondScore + kFactor * (1 - sa - expectedScoreSecond);
	}
	return scores;
}\n```"""

# Move models to device if not using device_map
if device.type != "cuda":
    model_amateur = model_amateur.to(device)
    model_expert = model_expert.to(device)

def contrastive_generation(amateur, expert, prompt, max_tokens, top_k=50, temperature=0.7, stop_tokens=None) -> str:
    if stop_tokens is None:
        stop_tokens = [tokenizer.eos_token_id]

    # Ensure input_ids are on the correct device
    user_hydrated_prompt = tokenizer.apply_chat_template(
        [
            {'role': 'system', 'content': 'You are a helpful assistant'},
            {'role': 'user', 'content': prompt}
        ],
        add_generation_prompt=True,
        tokenize=False
    )

    input_ids = tokenizer(user_hydrated_prompt, return_tensors="pt").input_ids.to(device)
    limit = input_ids.shape[1]
    generated_output = []
    amateur_past = None
    expert_past = None

    while limit < max_tokens + input_ids.shape[1]:
        with torch.no_grad():
            # Rest of your code remains the same
            amateur_outputs = amateur(
                input_ids if amateur_past is None else input_ids[:, -1:],
                past_key_values=amateur_past,
                use_cache=True
            )
            expert_outputs = expert(
                input_ids if expert_past is None else input_ids[:, -1:],
                past_key_values=expert_past,
                use_cache=True
            )

            amateur_past = amateur_outputs.past_key_values
            expert_past = expert_outputs.past_key_values

            # Get next token logits
            amateur_logits = amateur_outputs.logits[:, -1, :]
            expert_logits = expert_outputs.logits[:, -1, :]

            # Apply temperature
            amateur_logits = amateur_logits / temperature
            expert_logits = expert_logits / temperature

            # Get top-k tokens from expert
            top_k_values, top_k_indices = torch.topk(expert_logits, k=top_k)

            # Compute probabilities only for top-k tokens
            amateur_probs_topk = torch.nn.functional.softmax(amateur_logits[:, top_k_indices], dim=-1)
            expert_probs_topk = torch.nn.functional.softmax(top_k_values, dim=-1)

            # Compute contrastive scores
            epsilon = 1e-10
            contrastive_scores_topk = expert_probs_topk / (amateur_probs_topk + epsilon)

            next_token = top_k_indices[0, torch.argmax(contrastive_scores_topk)]

            if next_token.item() in stop_tokens:
                break

            generated_output.append(next_token.item())
            input_ids = torch.cat([input_ids, next_token.unsqueeze(0).unsqueeze(0)], dim=1)
            limit += 1

    return tokenizer.decode(generated_output, skip_special_tokens=True)


# Example run:
max_tokens = 100
response = contrastive_generation(model_amateur, model_expert, user_message, max_tokens)
print(response)
