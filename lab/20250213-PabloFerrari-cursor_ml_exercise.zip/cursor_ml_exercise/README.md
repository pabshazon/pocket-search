# Cursor ML takehome interview

## Problem 
Your goal is to implement [Contrastive Decoding](https://arxiv.org/abs/2210.15097) with HuggingFace transformers and PyTorch.

Your code should use `Qwen/Qwen2.5-3B-Instruct` as the large model and `Qwen/Qwen2.5-Coder-0.5B-Instruct` as the small model and be implemented in `main.py`.

Your code should be correct first, but also efficient. Implement the token-level algorithm, rather than the beam search algorithm.

In addition to implementing main.py, please answer the following questions:

1. What should you do if the two models have different tokenizers?
    We need to align the models vocabularies. We could map the tokens between them.
    For example, we could do this by converting the amateur tokens to match the expert tokens or viceversa, depending on requirements: I think there is probably a tradeoff in quality vs speed here, since the expert will probably have more tokens than the amateur - so the directionality will be an improtant tradeoff to consider. 

2. Do you think contrastive decoding is used in practice?
    My overall guess is "most probably not". Here are my thoughts about it: 
    It depends on the requirements, I guess there may be situations where this can be practical.
    Overall, I think having 2 models loaded in memory and running them will be a computaional and resources overhead, and if we go loading/unloading them it will be some extra ml ops that will add complexity and time to the response.
    Looks to me like a very valid solution if we want to add layers to ensure less hallucination, but other techniques like RAG, or fine-tuning a model would be better (again, depending in project requirements).
    

