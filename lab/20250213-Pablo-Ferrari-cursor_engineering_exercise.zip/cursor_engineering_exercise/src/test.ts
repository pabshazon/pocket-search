function otherTest() {
    console.log('a');
}
